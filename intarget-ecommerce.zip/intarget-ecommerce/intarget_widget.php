<?php
/*
Plugin Name: inTarget eCommerce
Plugin URI: http://intarget.ru/
Description: inTarget — система аналитики для интернет-магазинов.
Version: 1.0.1
Author: Intarget
Author URI: http://intarget.ru/
*/


// Creating the widget 

include 'widget_options.php';
